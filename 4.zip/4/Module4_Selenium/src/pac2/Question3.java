package pac2;


import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;

public class Question3 {

	WebDriver driver;

	@Before
	public void before(){

		driver=new FirefoxDriver();	
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@Test
	public void mainTest(){

		//Open URL
		driver.get("http://10.51.103.172/opencart/");

		//verifying title
		String title=driver.getTitle();
		Assert.assertEquals(title,"Your Store" );

		//Click on item button
		driver.findElement(By.xpath("//*[@id='cart']/button")).click();

		//verifying drop down
		String dropDown=driver.findElement(By.xpath("//*[@id='cart']/ul/li/p")).getText();
		Assert.assertEquals(dropDown,"Your shopping cart is empty!" );

		//Click on currency dropdown
		driver.findElement(By.xpath("//*[@id='currency']/div/button/span")).click();

		//CLick on Pound Sterling
		driver.findElement(By.xpath("//*[@id='currency']/div/ul/li[2]/button")).click();

		//Validation of currency
		String currency=driver.findElement(By.xpath("//*[@id='currency']/div/button/strong")).getText();
		Assert.assertEquals(currency,"�");

		// Click on contact button 
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[1]/a/i")).click();

		//verifying contact button
		String contactUs=driver.getTitle();
		Assert.assertEquals(contactUs,"Contact Us");


		//verifying default address
		String address=driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[1]/address")).getText();

		String phNumber=driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]")).getText();

		Assert.assertEquals(address,"Address 1" );
		Assert.assertEquals(phNumber,"Telephone\n123456789");

		//Entering details
		driver.findElement(By.id("input-name")).sendKeys("Shalem");

		driver.findElement(By.id("input-email")).sendKeys("igate.c.n");

		//Click on submit button
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input")).click();

		//Verifying error message
		String errorMessage=driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[2]/div/div")).getText();
		Assert.assertEquals(errorMessage,"E-Mail Address does not appear to be valid!" );

		//Entering valid email id 
		driver.findElement(By.id("input-email")).sendKeys("shalem@gmail.com");

		//Text enter in enquiry box
		driver.findElement(By.id("input-enquiry")).sendKeys("i am not able to book 3 led tv's at a time");

		//Click on submit button 
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input")).click();

		//Verifying the message
		String msg=driver.findElement(By.xpath("//*[@id='content']/p")).getText();
		Assert.assertEquals(msg,"Your enquiry has been successfully sent to the store owner!");

		//Click on continue button 
		driver.findElement(By.xpath("//*[@id='content']/div/div/a")).click();

		//Click on Brand Button 
		driver.findElement(By.xpath("/html/body/footer/div/div/div[3]/ul/li[1]/a")).click();

		//verifying the title 
		String brandTitle=driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
		Assert.assertEquals(brandTitle, "Find Your Favorite Brand");

		//Click on sony link 
		driver.findElement(By.xpath("//*[@id='content']/div[5]/div/a")).click();

		//Click on currency 
		driver.findElement(By.xpath("//*[@id='currency']/div/button/span")).click();

		//Click on Dollars
		driver.findElement(By.xpath("//*[@id='currency']/div/ul/li[3]/button")).click();

		//Validating the price
		String price=driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/p[2]")).getText();
		Assert.assertEquals(price,"$1,202.00\nEx Tax: $1,000.00");

		//Click on add cart button 
		driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[3]/button[1]")).click();

		//Verifying the success message
		String message=driver.findElement(By.cssSelector("div.alert-success")).getText();

		Assert.assertEquals(message,"Success: You have added Sony VAIO to your shopping cart!"+"\n�");

		//Click on cart button 
		driver.findElement(By.xpath("//*[@id='cart']/button")).click();

		//verifying Text
		String mesg=driver.findElement(By.xpath("//*[@id='cart']/ul/li[1]/table/tbody/tr/td[2]/a")).getText();

		Assert.assertEquals(mesg,"Sony VAIO");

	}

	@After
	public void after(){
		//Closing the browser
		driver.quit();

	}

}
