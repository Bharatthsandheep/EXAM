package pac3;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Question4_IE {

	public static void main(String[] args){

		//Opening IE browser
		System.setProperty("webdriver.ie.driver", "D:/841358/Selenium/Drivers/IEDriverServer.exe");

		WebDriver driver = new InternetExplorerDriver();

		//Opens the OpenCartApplication With URL...
		driver.get("http://10.51.103.172/opencart/");

		driver.manage().window().maximize();

		//Implicit wait For getting page to load...
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		//Verification of Title Message...
		String title="Your Store";

		if(!(driver.getTitle().equals(title))){
			System.out.println("Title verification Is Matched" );
		}

		//Displaying title page
		System.out.println("Title of the Page is : "+driver.getTitle());

		System.out.println("------------------------------\n");

		driver.findElement(By.xpath("//*[@id='cart']/button")).click();

		//Verification of Dropdown Message...
		String title1="Your shopping cart is empty!";

		if(!(driver.getTitle().equals(title1))){
			System.out.println("Title verification Is Matched" );
		}

		System.out.println("Drop down Message is : "+driver.findElement(By.xpath("//*[@id='cart']/ul/li/p")).getText());

		System.out.println("------------------------------\n");

		driver.findElement(By.xpath("//*[@id='currency']/div/button")).click();

		//Verification of Heading Message(contact us)...
		String title2="Contact Us";

		if(!(driver.getTitle().equals(title2))){
			System.out.println("Title verification Is Matched" );
		}

		//Click on Pound Sterling
		driver.findElement(By.name("GBP")).click();

		//Validation of currency
		System.out.println("Selected currency is : "+driver.findElement(By.xpath("//*[@id='currency']/div/button/strong")).getText());

		System.out.println("------------------------------\n");		

		// Click on contact button 
		driver.findElement(By.xpath("//*[@id='top-links']/ul/li[1]/a/i")).click();

		System.out.println("Heading displayed is : "+driver.findElement(By.xpath("//*[@id='content']/h1")).getText());

		System.out.println("------------------------------\n");

		//verifying default address
		System.out.println("Address displayed under our Location is");

		System.out.println(driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[1]/address")).getText());

		System.out.println("\nMobile number displayed is : \n"+driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]")).getText());		

		System.out.println("------------------------------\n");

		//Entering details of the customer
		driver.findElement(By.id("input-name")).sendKeys("shalem");
		driver.findElement(By.id("input-email")).sendKeys("igate.c.n");

		//Click on submit button
		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input")).click();

		//Verification of Email Error Message...
		String title3 ="E-Mail Address does not appear to be valid!";

		if(!(driver.getTitle().equals(title3))){
			System.out.println("Title verification Is Matched" );
		}

		System.out.println("Error Message displayed is : "+driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[2]/div/div")).getText());

		System.out.println("------------------------------\n");

		driver.findElement(By.id("input-email")).clear();

		driver.findElement(By.id("input-email")).sendKeys("shalem@gmail.com");

		driver.findElement(By.xpath("//*[@id='input-enquiry']")).sendKeys("i am not able to book 3 led tv's at a time");

		//driver.findElement(By.id("input-captcha")).sendKeys("");

		driver.findElement(By.xpath("//*[@id='content']/form/div/div/input")).click();

		driver.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);

		System.out.println("The message displayed is : "+driver.findElement(By.xpath("//*[@id='content']/p")).getText());

		System.out.println("------------------------------\n");

		driver.findElement(By.linkText("Continue")).click();

		driver.findElement(By.xpath("//*[@id='search']/span/button")).sendKeys(Keys.PAGE_DOWN);

		driver.findElement(By.linkText("Brands")).click();

		//Verification of Title Message...
		String title4="Find Your Favorite Brand";

		if(!(driver.getTitle().equals(title4))){
			System.out.println("Title verification Is Matched" );
		}

		//diplaying the title page name
		System.out.println("Title displayed is : "+driver.getTitle());

		System.out.println("------------------------------\n");

		//Clicking on sony link		
		driver.findElement(By.linkText("Sony")).click();

		//Click on currency 
		driver.findElement(By.xpath("//*[@id='currency']/div/button/span")).click();

		//Click on Dollars
		driver.findElement(By.xpath("//*[@id='currency']/div/ul/li[3]/button")).click();

		//Validating the price
		System.out.println("Price displayed is : "+driver.findElement(By.className("price")).getText());
		System.out.println("------------------------------\n");

		//Click on currency 
		driver.findElement(By.xpath("//*[@id='currency']/div/button/span")).click();

		//Click on Dollars
		driver.findElement(By.xpath("//*[@id='currency']/div/ul/li[3]/button")).click();

		driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[3]/button[1]")).click();

		System.out.println("Success message displayed is : \n"+driver.findElement(By.cssSelector("div.alert-success")).getText());

		System.out.println("------------------------------\n");

		//clicking on the cart
		driver.findElement(By.xpath("//*[@id='cart']/button")).click();

		//Verification the item from dropdown message...
		String title5="Sony VAIO";

		if(!(driver.getTitle().equals(title5))){
			System.out.println("Title verification Is Matched" );
		}

		//displaying item added to the cart
		System.out.println("Item present in the Cart is -- "+driver.findElement(By.xpath("//*[@id='cart']/ul/li[1]/table/tbody/tr/td[2]/a")).getText());

		System.out.println("------------------------------\n");

	}

}

